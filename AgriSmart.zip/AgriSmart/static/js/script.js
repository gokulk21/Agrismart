// Live total on the booking page
const days = document.getElementById("days"), total = document.getElementById("total");
if (days && total) {
  days.addEventListener("input", () => {
    total.textContent = (Math.max(1, +days.value || 1) * +total.dataset.price).toLocaleString("en-IN");
  });
}
