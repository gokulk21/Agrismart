import os, json, sqlite3
from datetime import date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "database.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOADS, exist_ok=True)
app = Flask(__name__)
app.secret_key = "agrismart-dev-key-change-me"

# ---------- database helpers ----------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, mobile TEXT, email TEXT UNIQUE, password TEXT, role TEXT, location TEXT);
CREATE TABLE IF NOT EXISTS farmers(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), land_area REAL);
CREATE TABLE IF NOT EXISTS sellers(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), business TEXT, verified INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, seller_id INTEGER REFERENCES sellers(id), name TEXT, category TEXT, price REAL, location TEXT, rating REAL DEFAULT 4.0, stock INTEGER, emoji TEXT);
CREATE TABLE IF NOT EXISTS seedlings(id INTEGER PRIMARY KEY, product_id INTEGER REFERENCES products(id), variety TEXT, age_days INTEGER);
CREATE TABLE IF NOT EXISTS machines(id INTEGER PRIMARY KEY, seller_id INTEGER REFERENCES sellers(id), name TEXT, price_per_day REAL, location TEXT, rating REAL DEFAULT 4.0, available INTEGER DEFAULT 1, emoji TEXT);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, farmer_id INTEGER REFERENCES users(id), product_id INTEGER REFERENCES products(id), qty INTEGER, amount REAL, date TEXT, status TEXT DEFAULT 'Pending');
CREATE TABLE IF NOT EXISTS bookings(id INTEGER PRIMARY KEY, farmer_id INTEGER REFERENCES users(id), machine_id INTEGER REFERENCES machines(id), start_date TEXT, days INTEGER, amount REAL, status TEXT DEFAULT 'Pending');
CREATE TABLE IF NOT EXISTS farming_plans(id INTEGER PRIMARY KEY, farmer_id INTEGER REFERENCES users(id), crop TEXT, land REAL, soil TEXT, water TEXT, season TEXT, prev_crop TEXT, schedule TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS crop_recommendations(id INTEGER PRIMARY KEY, plan_id INTEGER REFERENCES farming_plans(id), reason TEXT, water_req TEXT, duration TEXT, seeds TEXT, fertilizer TEXT, machinery TEXT);
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop("db", None)
    if d:
        d.close()

def q(sql, args=(), one=False):
    rows = db().execute(sql, args).fetchall()
    return (rows[0] if rows else None) if one else rows

def run(sql, args=()):
    cur = db().execute(sql, args)
    db().commit()
    return cur.lastrowid

def init_db():
    c = sqlite3.connect(DB)
    c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM users").fetchone():
        def user(n, m, e, p, r, l):
            return c.execute("INSERT INTO users(name,mobile,email,password,role,location) VALUES(?,?,?,?,?,?)",
                             (n, m, e, generate_password_hash(p), r, l)).lastrowid
        user("Admin", "9000000000", "admin@agrismart.com", "admin123", "admin", "Hyderabad")
        s1 = c.execute("INSERT INTO sellers(user_id,business,verified) VALUES(?,?,1)",
                       (user("Ravi Kumar", "9111111111", "seller@agrismart.com", "seller123", "seller", "Kurnool"), "Green Valley Agro")).lastrowid
        s2 = c.execute("INSERT INTO sellers(user_id,business,verified) VALUES(?,?,1)",
                       (user("Lakshmi Devi", "9222222222", "seller2@agrismart.com", "seller123", "seller", "Guntur"), "Sri Lakshmi Farm Tools")).lastrowid
        f = user("Demo Farmer", "9333333333", "farmer@agrismart.com", "farmer123", "farmer", "Anantapur")
        c.execute("INSERT INTO farmers(user_id,land_area) VALUES(?,?)", (f, 3))
        prods = [(s1, "Groundnut Seeds", "Seeds", 120, "Kurnool", 4.6, 200, "🥜"), (s1, "Rice Seeds", "Seeds", 80, "Guntur", 4.4, 500, "🌾"),
                 (s1, "Tomato Seedlings", "Seedlings", 2, "Hosur", 4.5, 3000, "🍅"), (s1, "Chilli Seedlings", "Seedlings", 2, "Guntur", 4.3, 4000, "🌶️"),
                 (s2, "Organic Fertilizer", "Fertilizers", 450, "Kurnool", 4.7, 80, "🧪"), (s2, "NPK 19-19-19", "Fertilizers", 620, "Guntur", 4.2, 60, "🧪"),
                 (s2, "Vermicompost", "Organic Products", 300, "Hosur", 4.8, 90, "🪱"), (s1, "Neem Oil Spray", "Crop Protection", 250, "Kurnool", 4.1, 70, "🛡️")]
        for p in prods:
            pid = c.execute("INSERT INTO products(seller_id,name,category,price,location,rating,stock,emoji) VALUES(?,?,?,?,?,?,?,?)", p).lastrowid
            if p[3 - 1] == "Seedlings":
                c.execute("INSERT INTO seedlings(product_id,variety,age_days) VALUES(?,?,?)", (pid, "Hybrid", 25))
        for m in [(s2, "Tractor", 1500, "Guntur", 4.6, 1, "🚜"), (s2, "Rotavator", 800, "Guntur", 4.4, 1, "⚙️"), (s1, "Seed Drill", 600, "Kurnool", 4.2, 1, "🌱"),
                  (s1, "Sprayer", 300, "Kurnool", 4.5, 1, "💦"), (s2, "Harvester", 3000, "Anantapur", 4.7, 1, "🌾")]:
            c.execute("INSERT INTO machines(seller_id,name,price_per_day,location,rating,available,emoji) VALUES(?,?,?,?,?,?,?)", m)
    c.commit()
    c.close()

def login_required(role=None):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **k):
            if "uid" not in session:
                flash("Please log in first.")
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                flash("You do not have access to that page.")
                return redirect(url_for("dashboard"))
            return fn(*a, **k)
        return wrapper
    return deco

# ---------- demo AI rules ----------
RANK = {"Low": 0, "Medium": 1, "High": 2}
CROPS = {
    "Groundnut": dict(soil=["Sandy", "Red", "Loamy"], water="Low", season=["Kharif", "Rabi"], days=(100, 120), seeds="Groundnut Seeds (about 50 kg/acre)",
                      fert="Gypsum + DAP + organic compost", machines=["Tractor", "Rotavator", "Seed Drill", "Sprayer", "Harvester"]),
    "Rice": dict(soil=["Clay", "Loamy"], water="High", season=["Kharif"], days=(120, 140), seeds="Rice Seeds (about 20 kg/acre)",
                 fert="Urea + DAP + Potash", machines=["Tractor", "Rotavator", "Harvester"]),
    "Tomato": dict(soil=["Loamy", "Red", "Sandy"], water="Medium", season=["Rabi", "Summer"], days=(90, 120), seeds="Tomato Seedlings (about 8000/acre)",
                   fert="NPK 19-19-19 + vermicompost", machines=["Tractor", "Rotavator", "Sprayer"]),
    "Chilli": dict(soil=["Red", "Loamy", "Black"], water="Medium", season=["Kharif", "Rabi"], days=(120, 150), seeds="Chilli Seedlings (about 10000/acre)",
                   fert="Organic fertilizer + NPK + calcium", machines=["Tractor", "Rotavator", "Sprayer"]),
}

def recommend(f):
    best, top = "Groundnut", -99
    for name, c in CROPS.items():
        s = (2 if f["soil"] in c["soil"] else 0) + (2 if RANK[f["water"]] >= RANK[c["water"]] else -2) \
            + (2 if f["season"] in c["season"] else 0) - (2 if f["prev"] == name else 0)
        if s > top:
            best, top = name, s
    return best

def order_rows(uid, limit=100):
    return q("""SELECT o.*, p.name pname, s.business seller FROM orders o JOIN products p ON o.product_id=p.id
                JOIN sellers s ON p.seller_id=s.id WHERE o.farmer_id=? ORDER BY o.id DESC LIMIT ?""", (uid, limit))

def booking_rows(uid, limit=100):
    return q("""SELECT b.*, m.name mname, s.business owner FROM bookings b JOIN machines m ON b.machine_id=m.id
                JOIN sellers s ON m.seller_id=s.id WHERE b.farmer_id=? ORDER BY b.id DESC LIMIT ?""", (uid, limit))

def place_order(pid):
    p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
    if not p or p["stock"] < 1:
        return False
    run("INSERT INTO orders(farmer_id,product_id,qty,amount,date) VALUES(?,?,?,?,?)", (session["uid"], pid, 1, p["price"], date.today().isoformat()))
    run("UPDATE products SET stock=stock-1 WHERE id=?", (pid,))
    return True

# ---------- public + auth ----------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        try:
            uid = run("INSERT INTO users(name,mobile,email,password,role,location) VALUES(?,?,?,?,?,?)",
                      (f["name"], f["mobile"], f["email"].lower(), generate_password_hash(f["password"]), f["role"], f["location"]))
        except sqlite3.IntegrityError:
            flash("That email is already registered.")
            return redirect(url_for("register"))
        if f["role"] == "seller":
            run("INSERT INTO sellers(user_id,business,verified) VALUES(?,?,0)", (uid, f["name"] + " Agro"))
        else:
            run("INSERT INTO farmers(user_id,land_area) VALUES(?,?)", (uid, float(f.get("land") or 0)))
        flash("Registration successful. Please log in.")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = q("SELECT * FROM users WHERE email=?", (request.form["email"].lower(),), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            session.update(uid=u["id"], name=u["name"], role=u["role"], cart=[])
            return redirect(url_for("dashboard"))
        flash("Wrong email or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# ---------- farmer ----------
@app.route("/dashboard")
@login_required()
def dashboard():
    if session["role"] == "seller":
        return redirect(url_for("seller_dashboard"))
    if session["role"] == "admin":
        return redirect(url_for("admin_dashboard"))
    uid = session["uid"]
    farmer = q("SELECT * FROM farmers WHERE user_id=?", (uid,), one=True)
    plan = q("SELECT * FROM farming_plans WHERE farmer_id=? ORDER BY id DESC", (uid,), one=True)
    stage, nxt, tasks = "No plan yet", None, []
    if plan:
        tasks = json.loads(plan["schedule"])
        el = (date.today() - date.fromisoformat(plan["created"])).days
        done = [t for t in tasks if t[0] <= el]
        todo = [t for t in tasks if t[0] > el]
        stage = done[-1][1] if done else "Planning"
        nxt = todo[0] if todo else None
    return render_template("dashboard.html", farmer=farmer, plan=plan, stage=stage, nxt=nxt, tasks=tasks[:4],
                           orders=order_rows(uid, 5), bookings=booking_rows(uid, 5))

@app.route("/ai-farming", methods=["GET", "POST"])
@login_required("farmer")
def ai_farming():
    farmer = q("SELECT * FROM farmers WHERE user_id=?", (session["uid"],), one=True)
    if request.method == "POST":
        f = request.form
        crop = recommend(f)
        c = CROPS[crop]
        lo, hi = c["days"]
        sched = [[0, "Land preparation & sowing"], [15, "Crop growth check"], [25, "Nutrient management"], [40, "Weed management"],
                 [50, "Fertilizer recommendation"], [70, "Irrigation & field check"], [lo, "Harvest"]]
        pid = run("INSERT INTO farming_plans(farmer_id,crop,land,soil,water,season,prev_crop,schedule,created) VALUES(?,?,?,?,?,?,?,?,?)",
                  (session["uid"], crop, float(f["land"]), f["soil"], f["water"], f["season"], f["prev"], json.dumps(sched), date.today().isoformat()))
        why = (f"{crop} grows well in {f['soil']} soil during {f['season']} season and needs {c['water'].lower()} water, "
               f"which fits your {f['water'].lower()} water availability. Your previous crop was {f['prev']}, so this also helps crop rotation.")
        run("INSERT INTO crop_recommendations(plan_id,reason,water_req,duration,seeds,fertilizer,machinery) VALUES(?,?,?,?,?,?,?)",
            (pid, why, c["water"], f"{lo}–{hi} days", c["seeds"], c["fert"], ", ".join(c["machines"])))
        return redirect(url_for("farming_plan", pid=pid))
    return render_template("ai_farming.html", farmer=farmer, crops=list(CROPS))

@app.route("/plan/<int:pid>")
@login_required("farmer")
def farming_plan(pid):
    plan = q("SELECT * FROM farming_plans WHERE id=? AND farmer_id=?", (pid, session["uid"]), one=True)
    if not plan:
        flash("Plan not found.")
        return redirect(url_for("ai_farming"))
    rec = q("SELECT * FROM crop_recommendations WHERE plan_id=?", (pid,), one=True)
    names = CROPS[plan["crop"]]["machines"]
    machines = q("SELECT m.*, s.business owner FROM machines m JOIN sellers s ON m.seller_id=s.id WHERE m.name IN (%s)" % ",".join("?" * len(names)), names)
    prods = q("""SELECT p.*, s.business seller FROM products p JOIN sellers s ON p.seller_id=s.id
                 WHERE p.name LIKE ? OR p.category='Fertilizers' ORDER BY p.category""", (f"%{plan['crop']}%",))
    return render_template("farming_plan.html", plan=plan, rec=rec, schedule=json.loads(plan["schedule"]), machines=machines, products=prods)

@app.route("/marketplace")
def marketplace():
    sql = "SELECT p.*, s.business seller FROM products p JOIN sellers s ON p.seller_id=s.id WHERE 1=1"
    a = []
    cat, loc, mx, txt = (request.args.get(k, "") for k in ("category", "location", "max_price", "q"))
    if cat:
        sql += " AND p.category=?"; a.append(cat)
    if loc:
        sql += " AND p.location LIKE ?"; a.append(f"%{loc}%")
    if mx:
        sql += " AND p.price<=?"; a.append(float(mx))
    if txt:
        sql += " AND p.name LIKE ?"; a.append(f"%{txt}%")
    return render_template("marketplace.html", products=q(sql, a), cats=["Seeds", "Seedlings", "Fertilizers", "Organic Products", "Crop Protection"])

@app.route("/cart/add/<int:pid>")
@login_required("farmer")
def cart_add(pid):
    session["cart"] = session.get("cart", []) + [pid]
    flash("Added to cart.")
    return redirect(request.referrer or url_for("marketplace"))

@app.route("/cart")
@login_required("farmer")
def cart():
    ids = session.get("cart", [])
    items = [q("SELECT p.*, s.business seller FROM products p JOIN sellers s ON p.seller_id=s.id WHERE p.id=?", (i,), one=True) for i in ids]
    items = [i for i in items if i]
    return render_template("cart.html", items=items, total=sum(i["price"] for i in items))

@app.route("/cart/clear")
@login_required("farmer")
def cart_clear():
    session["cart"] = []
    return redirect(url_for("cart"))

@app.route("/cart/checkout", methods=["POST"])
@login_required("farmer")
def checkout():
    n = sum(1 for pid in session.get("cart", []) if place_order(pid))
    session["cart"] = []
    flash(f"{n} order(s) placed.")
    return redirect(url_for("orders"))

@app.route("/buy/<int:pid>")
@login_required("farmer")
def buy(pid):
    flash("Order placed." if place_order(pid) else "Product is out of stock.")
    return redirect(url_for("orders"))

@app.route("/machinery")
def machinery():
    return render_template("machinery.html", machines=q("SELECT m.*, s.business owner FROM machines m JOIN sellers s ON m.seller_id=s.id"))

@app.route("/booking/<int:mid>", methods=["GET", "POST"])
@login_required("farmer")
def booking(mid):
    m = q("""SELECT m.*, s.business owner, u.mobile owner_mobile FROM machines m JOIN sellers s ON m.seller_id=s.id
             JOIN users u ON s.user_id=u.id WHERE m.id=?""", (mid,), one=True)
    if not m:
        return redirect(url_for("machinery"))
    if request.method == "POST":
        days = max(1, int(request.form["days"]))
        run("INSERT INTO bookings(farmer_id,machine_id,start_date,days,amount) VALUES(?,?,?,?,?)",
            (session["uid"], mid, request.form["start"], days, days * m["price_per_day"]))
        flash("Booking confirmed and sent to the owner.")
        return redirect(url_for("orders"))
    return render_template("booking.html", m=m, today=date.today().isoformat())

@app.route("/crop-health", methods=["GET", "POST"])
@login_required("farmer")
def crop_health():
    result, img = None, None
    if request.method == "POST":
        file = request.files.get("image")
        if not file or not file.filename.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
            flash("Please upload a PNG, JPG or WEBP image.")
        else:
            name = secure_filename(file.filename)
            data = file.read()
            with open(os.path.join(UPLOADS, name), "wb") as fh:
                fh.write(data)
            img = "uploads/" + name
            result = [("Possible nitrogen deficiency", "Older leaves look pale yellow with slow growth.", "Nitrogen-rich fertilizer or compost", "Apply a balanced dose and recheck in 7 days."),
                      ("Possible fungal leaf spot", "Brown circular spots are visible on the leaves.", "Crop protection (fungicide) and potassium", "Remove affected leaves and avoid overhead watering."),
                      ("Crop looks healthy", "Leaf colour is even and no stress is visible.", "Maintenance NPK dose", "Continue your farming schedule.")][len(data) % 3]
    return render_template("crop_health.html", result=result, img=img)

@app.route("/orders")
@login_required("farmer")
def orders():
    return render_template("orders.html", orders=order_rows(session["uid"]), bookings=booking_rows(session["uid"]))

@app.route("/cancel/<kind>/<int:rid>")
@login_required("farmer")
def cancel(kind, rid):
    if kind in ("orders", "bookings"):
        run(f"UPDATE {kind} SET status='Cancelled' WHERE id=? AND farmer_id=? AND status='Pending'", (rid, session["uid"]))
    return redirect(url_for("orders"))

# ---------- seller ----------
STATUSES = ["Pending", "Confirmed", "Completed", "Cancelled"]

@app.route("/seller")
@login_required("seller")
def seller_dashboard():
    s = q("SELECT * FROM sellers WHERE user_id=?", (session["uid"],), one=True)
    prods = q("SELECT * FROM products WHERE seller_id=?", (s["id"],))
    machines = q("SELECT * FROM machines WHERE seller_id=?", (s["id"],))
    orders = q("""SELECT o.*, p.name pname, u.name farmer FROM orders o JOIN products p ON o.product_id=p.id
                  JOIN users u ON o.farmer_id=u.id WHERE p.seller_id=? ORDER BY o.id DESC""", (s["id"],))
    bookings = q("""SELECT b.*, m.name mname, u.name farmer FROM bookings b JOIN machines m ON b.machine_id=m.id
                    JOIN users u ON b.farmer_id=u.id WHERE m.seller_id=? ORDER BY b.id DESC""", (s["id"],))
    earn = sum(o["amount"] for o in orders if o["status"] in ("Confirmed", "Completed")) + \
           sum(b["amount"] for b in bookings if b["status"] in ("Confirmed", "Completed"))
    return render_template("seller_dashboard.html", s=s, prods=prods, machines=machines, orders=orders, bookings=bookings, earn=earn, statuses=STATUSES)

@app.route("/seller/add-product", methods=["POST"])
@login_required("seller")
def add_product():
    s = q("SELECT * FROM sellers WHERE user_id=?", (session["uid"],), one=True)
    if not s["verified"]:
        flash("Your account must be verified by the admin before you can list items.")
        return redirect(url_for("seller_dashboard"))
    f = request.form
    pid = run("INSERT INTO products(seller_id,name,category,price,location,rating,stock,emoji) VALUES(?,?,?,?,?,4.0,?,?)",
              (s["id"], f["name"], f["category"], float(f["price"]), f["location"], int(f["stock"]), f.get("emoji") or "🌿"))
    if f["category"] == "Seedlings":
        run("INSERT INTO seedlings(product_id,variety,age_days) VALUES(?,?,?)", (pid, f["name"], 25))
    flash("Product added.")
    return redirect(url_for("seller_dashboard"))

@app.route("/seller/add-machine", methods=["POST"])
@login_required("seller")
def add_machine():
    s = q("SELECT * FROM sellers WHERE user_id=?", (session["uid"],), one=True)
    if not s["verified"]:
        flash("Your account must be verified by the admin before you can list items.")
        return redirect(url_for("seller_dashboard"))
    f = request.form
    run("INSERT INTO machines(seller_id,name,price_per_day,location,available,emoji) VALUES(?,?,?,?,?,?)",
        (s["id"], f["name"], float(f["price"]), f["location"], int(f["available"]), "🚜"))
    flash("Machine added.")
    return redirect(url_for("seller_dashboard"))

@app.route("/seller/update/<kind>/<int:rid>", methods=["POST"])
@login_required("seller")
def seller_update(kind, rid):
    s = q("SELECT * FROM sellers WHERE user_id=?", (session["uid"],), one=True)
    f = request.form
    if kind == "product":
        run("UPDATE products SET price=?, stock=? WHERE id=? AND seller_id=?", (float(f["price"]), int(f["stock"]), rid, s["id"]))
    elif kind == "machine":
        run("UPDATE machines SET price_per_day=?, available=? WHERE id=? AND seller_id=?", (float(f["price"]), int(f["available"]), rid, s["id"]))
    elif kind in ("orders", "bookings") and f["status"] in STATUSES:
        run(f"UPDATE {kind} SET status=? WHERE id=?", (f["status"], rid))
    flash("Updated.")
    return redirect(url_for("seller_dashboard"))

# ---------- admin ----------
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    n = lambda sql: q(sql, one=True)[0] or 0
    stats = {"Farmers": n("SELECT COUNT(*) FROM users WHERE role='farmer'"), "Sellers": n("SELECT COUNT(*) FROM users WHERE role='seller'"),
             "Products": n("SELECT COUNT(*) FROM products"), "Machines": n("SELECT COUNT(*) FROM machines"),
             "Orders": n("SELECT COUNT(*) FROM orders"), "Bookings": n("SELECT COUNT(*) FROM bookings"),
             "Revenue (₹)": n("SELECT SUM(amount) FROM orders WHERE status!='Cancelled'") + n("SELECT SUM(amount) FROM bookings WHERE status!='Cancelled'")}
    return render_template("admin_dashboard.html", stats=stats,
        farmers=q("SELECT u.*, f.land_area FROM users u LEFT JOIN farmers f ON f.user_id=u.id WHERE u.role='farmer'"),
        sellers=q("SELECT u.*, s.verified, s.business FROM users u JOIN sellers s ON s.user_id=u.id"),
        products=q("SELECT p.*, s.business seller FROM products p JOIN sellers s ON p.seller_id=s.id"),
        machines=q("SELECT m.*, s.business owner FROM machines m JOIN sellers s ON m.seller_id=s.id"),
        orders=q("SELECT o.*, p.name pname, u.name farmer FROM orders o JOIN products p ON o.product_id=p.id JOIN users u ON o.farmer_id=u.id ORDER BY o.id DESC"),
        bookings=q("SELECT b.*, m.name mname, u.name farmer FROM bookings b JOIN machines m ON b.machine_id=m.id JOIN users u ON b.farmer_id=u.id ORDER BY b.id DESC"))

@app.route("/admin/verify/<int:uid>")
@login_required("admin")
def admin_verify(uid):
    run("UPDATE sellers SET verified=1-verified WHERE user_id=?", (uid,))
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/delete/<table>/<int:rid>")
@login_required("admin")
def admin_delete(table, rid):
    if table in ("products", "machines"):
        run(f"DELETE FROM {table} WHERE id=?", (rid,))
    elif table == "users":
        run("DELETE FROM farmers WHERE user_id=?", (rid,))
        run("DELETE FROM sellers WHERE user_id=?", (rid,))
        run("DELETE FROM users WHERE id=? AND role!='admin'", (rid,))
    flash("Deleted.")
    return redirect(url_for("admin_dashboard"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
